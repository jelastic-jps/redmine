// Italian translation
// by Diego Pierotto (ita.translations@tiscali.it)

jsToolBar.strings = {};
jsToolBar.strings['Strong'] = 'Grassetto';
jsToolBar.strings['Italic'] = 'Corsivo';
jsToolBar.strings['Underline'] = 'Sottolineato';
jsToolBar.strings['Deleted'] = 'Barrato';
jsToolBar.strings['Code'] = 'Codice sorgente';
jsToolBar.strings['Heading 1'] = 'Titolo 1';
jsToolBar.strings['Heading 2'] = 'Titolo 2';
jsToolBar.strings['Heading 3'] = 'Titolo 3';
jsToolBar.strings['Highlighted code'] = 'Highlighted code';
jsToolBar.strings['Unordered list'] = 'Elenco puntato';
jsToolBar.strings['Ordered list'] = 'Elenco numerato';
jsToolBar.strings['Quote'] = 'Aumenta rientro';
jsToolBar.strings['Unquote'] = 'Riduci rientro';
jsToolBar.strings['Preformatted text'] = 'Testo preformattato';
jsToolBar.strings['Wiki link'] = 'Collegamento a pagina Wiki';
jsToolBar.strings['Image'] = 'Immagine';
